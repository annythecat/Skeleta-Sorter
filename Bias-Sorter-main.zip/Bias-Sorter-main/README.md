# Bias-Sorter
 A bias sorter I created with the help of a friend. It allows you to rank items using a round robin series of "battles".
